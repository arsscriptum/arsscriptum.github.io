<#
  ╓──────────────────────────────────────────────────────────────────────────────────────
  ║   PowerShell PowerShell.Module.Downloader Module
  ║   Version 1.0.2 , Generated on Sun, 13 Feb 2022 18:26:15 GMT 
  ║   Description: 
  ║   Current Git Revision 7e7893f2debb5cef0275261585967df41fd74d33
  ╙──────────────────────────────────────────────────────────────────────────────────────
 #>


# ------------------------------------
# Script file - Aliases - 
# ------------------------------------
$ScriptBlockAliases = "H4sIAAAAAAAACnWOSwrCQBAF94Hc4W1EXQzoETR+UPyB4r51OiTazshMa65vDAQRkV7Wo6rTJG1uw5UZSUkRZkM3hhWYI8mD8SbjxWG/9CeYCcdzKO9aeoduFpiUQXBcwfrKiScLpXjtwsx8OPOv93RpvXPW1lvDL3GNoAVDyqjwOd4zNLueDxgvY/9/wIp1bSLzt7uw8r9Otl3vVtPDFCTSBD8hLUhR0LP+mNlhOBh0oIFczDmw/eTTJHkBm17VVEMBAAA="

# ------------------------------------
# Script file - BitsAdmin - 
# ------------------------------------
$ScriptBlockBitsAdmin = "H4sIAAAAAAAACu0bTW8bx/VuwP9hsGVLMhEpyUnawgYTUCRlM5YogaSjBpLgrMghufVyl5ldmmIdXQqkPfUjbXopkEOL9tCgaHto0UP1n5Sf0PfmY3d2d0hRlJ0mhdegtdyd9+a9N+97hnfv3OX/BlOvFzq+Rzo0LO00u52WHzqDeW3c33M8+uLuHQLXMXx1abjjeH3HGxY608nEZ2HQGflTt3/I/B4NguKpGDuxmT0uiHsOe4gPaEhZYd/2+nbos3klF7Ip3fjAdqd0l/njQ2dCXZhOPj/0AwdpqmxtxHjwekTdyT7MZQ9pxUJiyfv+GfEAvVUkp9qcQciA0NMcvG7B242XQ872MnJq/ngMCBcQIt9u8KfXUTOw3WAFcu4VTTNV2XA6pl5YsSw1U1H8yXmkQh7KZQbJBDV/6oXkAXEGBXhXoh+TreILMmNOSEu1ke151JXsEavlkx8DiAXDGQ2nzHtALgRaiRyRVuv7zValMIQ5eoJhcuaEgd0fO16ZntNiueNPWY9KkNZBt7nbbLQr+dr9E1CjIcgiOOnMg5COu77vBidcGR3KEDgvoJBYxSOnOZ8vSjXF63tWTIlFNkGrEwpNlEoQS62JRVpP9vYEhgsKkr8ltog6ifLunYuUqbVpIFehQ9lzp0cJTLmmpZFCEZdg2QrHcoNFHoa4yDGHYrVHfhAS66jabjVbDy1SGgCNfVI6I3WbPXvI7DkptfwWnXGmH5CcXWlTu196hGAlIGs8AfDuyAnIzHFd0rO9HnWJDbchs71gQBkqJ9cggmTgTbFMqoySuT8lwRRuCvPNVvE9VDAk1SYlzw/HdtgbEWsOVvVCqp3UuotY9dZXwE6POZOwTkHiFCSXz8HKTN0wgHvLkmNqI8ft45PCsOcAs3Y4IsQChX0SUAb2UKo7jPbQcIvl3anrojoI0F2fNezeqEByfYcRx1O4dPHnOtMzjrICrszxBHo+3jqpTiZ1O7RP2r4N5A9P9p0e8wN/EJ60aDjz2bOTuj/zXN/uUyapxeuIryhfGut4B7ivIvdc504JX1tcVL6+0ZqaoWuPGrXHoBARlRH0h9R1/ZkRASxelwah5ESxx7925xNKar4X2gDBdDGkZ278qNnpdspwJQhO+M7b85rGEFHbOAdUKWaTYLmuH6mNphgxv7uOS/n/4NuJ9fF4yN4ov2EJFcGAlUY3nnAIwAZklrp0DHZvszk+TOuVujT9AmND/VJEpUX7ckQVu4t0cOCzooEjJUvlhlebjv3ntNQELy9IL31A2ZkfUAIC88E6SalNe1MGD0oNxnxWFW4TNcfxppS8/e67kcSS6C9SYlX2/KZwi4gBw0Yk7lLb1ghMe/+02Ej9oNFpdYnQzojPh4xST8MiHZSMVzdaWumROqE/gfHH4tuO6/eend6/X2PUDmkh79GQBDiCZ0Cb83wxBWyz8DpoHILgKVg+OFJsM4aE11Tg8K7/Exl8wG/hVxC0A4kM4XqmIpQuznaj0+h20b90HzWIFmc1XcxClcyXUetS4Zuhsos3HZfSCdkWX8xKjYswQaXmYg5EpOYuSUA1vef+MwCTcaakCSuxjjhiMgU3wBOFMnyPhKPk9kDS8xbcHenECP0llk4CX/sJhUzjwTLyI5s8mw4g/pIBqFtwM/J1bXgZXNR9j15DNVfe2wodlfsm9OpKtlzwgFkKXuYfibwOzVtmXrfI6FaqnYyp/xPmbqxUWxihUVBQNKyBoeo6dlDIT/Ib+QkEv7wRfR2SAsezUVAYIdebCWoiB95SSMQLeYgVdMggw+3DxI+c4Qj+tHw2tl242fNnZjoOmePDSs8rlhgrFUs6spDN9ezs5jklB2tWcC3Ke3YQNr0+PT8YFPKb+SJ5U3kcPgqGyMDAR0Pq0OE0FnJNSQ1emAxzHcZax7LSoV28g9z1/YOdp3mYIUKbiEhJfKm1WIQ6PUy49zod2GAbKvfEN9fCablt+iVnIIkA7YhnBwtA+EueTEa5d5Q56AlDc+iBipBPyME0LLUg0JJbESoFuzxfAPFC/hRClZOG/4REeXGRmDK0cMQgp7Z2fRcSetL3aUCgBCL03AlCLb+XK3rjSY05+DJCuiNKOKCtyu3xFCLwGSV2LPgyQZkE4LrCUQAjKacZKj9/Rvvl5WTfWv66XudUr6CCSqq+QC6SVFBzpdNqHEFyd9TaO6jWSbfaebygnsqmHToJ5pDG0yYMacpieNOKq71l8E/NPoghmbiQzXb1qN3oPmm3yKbnz5g9IZs9no1B0SIRxahEVCvtQyXuBLTng8N6Z2vLJAL0Be9By8cY+pBKMUm/TIAqoMy6IKjy5IVSkUa7fdAmtXajyvM48EGSseTSYBm7Gld2v4+JimIL/sKq45+UNmCb4Do+BVeqtrAEX/cFNdaKQuCetNrv00W8V+t15Hy3uddApiOWVWMInDv+LbfpxLV7tGDlrQ3oWK0lnEz7KZaS0ncrnvnrERDQRARRRFK1QFCi2VcDRTloJSS1Ov845zjm+uthEM2Ap5QLVaDTrbaz6r/e+h62mwftZvfDiMkoX1mZK90l0hmSX+ERVbkfeNLwIM9Bg5bpAxoZySs+8rEvNXhhRQ/ZItvw0aQtnUv8QHTsFBn4nMulh009vckaCwbcmmgdCrq00K25t5E/KzXOe3SCRNUpRDKoMnNPoRiAN7BUvWdZErwIhaEfi6UCFjlR23TtbQ+wa2Me+fI770lXE6TwJ3Ubn2SSOwkl/n5CZiMKsRukF04D0Vbvtqutzi6oeKOeFyurYDXt1pVtOpY4t0zTa+/5kzKXwUUq0ZVjpESSJEujA3nwMTMH1DEQBCtaG3XNrC9uncjHdwNIJLHXloOl4K02o0wdjN04pNysp15hz0+9zGa8OcmHHCCWITVE1Qo4IGWVmWxQ4csspCndywFz0GgXCQi2vqU94Dd0H+AmXmxdkPvkxfaFZQJ3qOiQA/8bnFHDoP1gWCkkZ4KGjYTVwqG6jLaAWBZ1NiN/qHuT2sH+4V6j20DSTKQbffMms2fSb8QILIFh0eypoJGOMEsHR138Pm/SkErlXbHaRoodVimgqYv2qWgiRtl4VrM4UOMc24kJzafnExd0mpkVX10gGICFKAQzZN8uTO4j/3SR9vVCALxIA5ed9MiRP854ytv44zXNX+bjx6enC5TEEL8hCYH2ooAHIywISLRBcGyuWySlA0a0p5AHJvaCMh40U2B+B2UDjhCqrOn4DOKzP+DBwYiETyTcbCRocRMFZjF2mfx5dbeG/A9XamUt7kbJLDbRnPkal5F3S6Nc+haLakxAkquAoKYl6DzvQbNd9B6RCoVWCkMECSEJ1aFUcVw0jOTuqY4DdqD04JJx/dGGdMrha05ew7ahqJCDVnHySxx7UgTYPNc3yZUW5nrB0o0GPibgrWDsi2G3PJJP3w+e98SQxHPUIMPj2dSe4r3aygnOeKMZdkYE/rPUzoh4WlyhVS0xJbrSwFeqay0QSV0geU59PvUQSU8/0+hOyxQKmVcoVIE/K9Xkc428/xfB8i6bQa5HxpQ+MxpsDebgGRc69+ixzMfBosSGiDpNoazSqyw47ZGr+0CwchGcfil8yWzKD+CG8CIALoh4/DLGalPGQOrunNggl+dUnPiA2tQjlu5CY+KEz+R7bbSfV940QU5qiO5dF7QkEpwmZAHbhEc280DQqyLh3KclZEJjPhRT9/kJl5kN9V7oy51XXGNpDMENz73E1qTrjzldMK9RWjy8u6ZJaGV4IRkET8omXT8ZKm5da78ByYWypldUpd8wb5FAcSJnsPEF4VsfifEborjedQ6y0TxKAVcO4NeG8cjQF5fzS7Ki2ybeuLh78J2fX+BHCSEFdl3KFS8oVxmcZsP3EF08OosqBCfOuqNaf0fsnGO5j6QkameNTJiw6Q18lKaAKHcmrgMblETv8xI1TmhVJfquZ+iGcvaw2u5gc5FXhQJ/xsIMYInJElPH0MkmVdpCmnWNyOOt0wUjVZdbDdxeNBAGSH+ujb6XHu36ciwvPLoy3vGzX4nGUnJw1w9tvjkUqHdLBu/Mwxti5hAa5qz0tV5XLPYSmMQPTB2X5VxGwnkrJZzreY5A31kKapJABPp9A6jG2vEPTyFEgft/0nrcgi0zY0vpehlq6LLgqX3Ci2tUb/kGSwIk6l6v1JAHZz1RANFGmxGvdFWZytkMxvvtkEaX8tduiGbG8P37tDfKOiXpu1QXwOiR0kwIqiTo8dsmFVpwmkMDy6hPolkt2Iy2F4TEFm7WitHLtjCEn9J2MTQ3s9IuhskIU9ZlspikWhsoxhBTho1DbjdF40ZGpjkWu3GZXArv32gTsdG0Cx/J6tOURl0fI/WNlSTsChsq1zX/USkPOzt4FidKxbDDz48ZBI/pvJCXOVcyfzcELlACKB8G4uCs4FZkwyprS3GuUgkV9k0tkGTCp3GR6cVILOnyLj6xf9vtoXWPqi852W9O01c7g28t/XGAuaS5xan9ZU33+HDmRaRfqe5FzL+yX0XsjasHcbv+Wbub/LLoVR1hi+qXNZUq/euWRjfafo5OESQn4yuiWwXsx6sl+V8vxUuWBpxOfrIPG0c69qWFLEad4JslhFfzgy8ZkAuJYrMUKYy8UTTw80x51UFVpxW1H3MhNkwoRTtd8z4ygTzbluliORWEsyPvqZGm0Cwo4a+bGqxewGg7s3HxDtzD6+2tLfIGKRAkZxP+vxf3DfQDYh95lfUu/dQ7R6tjvbr809Xl368u/311+bery7/y+z/AQ3J1+SX/8ke4+9fV5T/4QHjzz6vLP5tOxOtIXxahyV+WcHGear+NsIXn0Ad99cVn//nqi9/8Fj4/hc+v4PM5fH4On5/J5/j304/CBb9LiQ6Yy9/tnG1fxyxM+RdA+Xv4/E6i/5xIOn4tHyItv1h9znsrzPmlRP9L+HyG6OXcioZPyXdXnhD0MP2Tk2R4xMSlVHXd5WnK6wMrkeG/PrDy7TywMtPMIh2AtUDEfxeehV7j1MLKR87MP/bVkqTXR8uiBW42Wt2nvLD9dhwvi+l9fcbMbLLaiq50zkym2N/yM2ZtWSisecJMgsvzZUb4NTzW4nNWd/4Lf2u/efpDAAA="

# ------------------------------------
# Script file - Helpers - 
# ------------------------------------
$ScriptBlockHelpers = "H4sIAAAAAAAACuVZ62/iOBD/Xqn/g8VGAqSC2ntfV0hHeXTZLYQDur1Ti64pcSG3weYcZ1u22//9xo+8Q9pl6eqkCx8I9nhmPPOb8XjY39uHz8y1PA+1FhYh2B0yusKMO9jb33vY30PwvMqZEuOXHmcOmU8NPY8aqHzSm4yb7X5vUNY0LUo86uIWdSmbGhOH63dJ7Po4n66PPc+aR5Rti304ZdY6n7rDGGUJ2hG280nH/mwGvFOMMSYFnNvYmzFnxR1KEuv+xK5L72Dh4/6eMZYkxzFTeUB3mTHd9PiY4LtKVRh+f+/WJzPBF10wh+Oapta7fxAKxZ5XaGB2/hiaown8CNRd2i7mJw6xwROVsb9aUca98YL6rg1CxV6rU0W7spi1rKh3uXYoBjDHrNK3iG1xytYNgzMfHwyp5wi1GofB4oS/tX4HT/G6tVwvxuwol5kpDWu5akraRbwog7yhHkelS6NinLr0xnIT9q3rH9UpKqHaLdpAFWGuimoDOsB3Zw7BSopzWzGG4xPqEzvcAfClhFsO8d7hdaUc6FeuVnU8pNUL7FGkRBzQWTUyHAOhRSzjUAazCR6PGAy+Ky01SwnvzVgdYc93eRqq+ZiVz38MuN6dw2eLqXFhMQI0KRQKfOgZVMP/IKMrIL0JCC+H04wkZL5DxewS8MgwLELK5UVzNChmHmXcHNbqKxvGWyBQQ28T+KQaD09jDn0L8CUQN157HC/rQAK7WWLC602f06Ul9qCsN8Izyuypob5D3Ikv45YyIFWohVOk9HD4eE0ejh5LwbyDXVucL3p1veu77vp333IdmLIl/559EMx27mdYJpT6hI4lU3H+SE5qqu/NG5WkVOEiJUaTfhugJ6R0RiNztD0QE9gLN3pNrglw7FKG50wkfnWmRwe6Rl2IuFPMa218a0Gaa9M74lILzgq+2JjyYvjbFm5h/jH61PZdPADECW937vHMV3UI4fie18ewFH6OucVxXdHqhSM8F1oK9Bidwftjk80t4nySAHzzrnV+FWNditbAkaeFlXP2XA4JRdJHjYqwTQ+AruubNapJoaH0mmQWY1yt57BVXBnmPiMB8+yxI2QNKBcIZ83V6n/hA7XfmVyh95z0QaPcOr4C/eegsnelss6EUte7CkxVx/dBkQ2n2QR7vAYyHAjz9XsLCvCMyzoEphI+i50ToeulO76QUZiAE0fEU36HmK4FaHlLbyTXhxfzOwpy/eUqTPRRVXGwKedfggkcmMFg9gEkY5N1liu+rkQEQQ0CeblAwtEOJAhTF8n4bgcyzplbJOL7HYgQAeV7B3KwQNQPu7CYjpWiLf24Azlwk+QOkdEsQqRI3E87EDdkDoUzcF0k5+eD9IXtCwS5VIjpOi72Jswi3i1m2IYoKZD3y9fLm1BuuVJosahfv17UyZo/f2tHhzvam5TaOMwkN10kBi8GZEPRYxiOW74HxaV58zee8elvsXQdPL12egROsp6uOuOPTtNJQjGYJYUUkOUJg1lKFckpSjWYJU6hKSBPDWfXRahIiImGs0tS3g2WpIY3iJJUWVFyOLskCMW0vYLxHE/onJQgDwaz5KnUoshTg9Hhmzx5AUfpordHANMA2U+4Jlp6qk55eKnrUzJWCjKmqInK4kjYnmNgwpBd6sovqovgPWgBpLUQrYBSKV4XiSdH2csO+egwSsQNEDp/UDN1qWsr4ZUS0H/gdNV2GMQtqF2qPsnwLXWIrrPSk1Hv9a+2eTE4M5vtsd5ciCkopUS5HpRqmX2Jycl6hVGok7wpzaC4kzetpkbHnMD1CX1Gpg81OaSzmD/SnQVtQ1G6o6wlPyNZkYr3KkobVLpjwegdKimzIZtCzBHghO+h8NQ1cyh5C6HKEnLLuuuHWaEikwVGcqHF5r5wK1pC8kU3GFmR0eoqiwH6+cIDSix1tsTtEtv1zWo/poGXAOsG1MVp1I2sRZdLCAW4wumyGQZWELEgW1wG8nxZrY+pD37OmDCrgiEcnmehdGhVoKKn7kesDF0KW+Q+Y2A3MXh145BStR7lpiJ2MegnZjbsMmPkLDrAKepClMM1wsUZtm4Tvd/guUv3zHqDU92t0P9B5Pbx8pa3moOBOUHd3qANF5hJr9vrjFBzODzrtZqTnjkImQYtiqeMVc7u/3kBmuDzTaJzk8S0C7aNShGKRTEXvMQRsvWdf9t7v1yXDRAYbaDxynUCjGqS/rpHPlLVF6j31zrgw0DK7+tek8ZunzjU80W2zEG3d3o+kiBGZhcNzYvOaPymc3aG+mb7/KwTN3UK5a/zeb7gJhQM8oQGOUahDJ5rXopFd1Jx9DrZe0ydP1Ki+Ddzg6x40wdB16dQ1utUnzMeTU8J2rElZV81BogYsomoEeBECAuQqEsky4tqPXnHCBYE9MX9xdxWJaqprlSe+aXMtE0Sf2iBx7M8MwVTaWuN8xp7kcYpJz5H3RyGyUOhtLWu0V3ADnU8ep5WsaWR/CfWjOFWsoJqTB/mB+I0AaPPgxz+CJucLWJngTpIsahpKsZfmf8t9/4FIc+sRuYgAAA="



# ------------------------------------
# Loader
# ------------------------------------
function ConvertFrom-Base64CompressedScriptBlock {

    [CmdletBinding()] param(
        [String]
        $ScriptBlock
    )

    # Take my B64 string and do a Base64 to Byte array conversion of compressed data
    $ScriptBlockCompressed = [System.Convert]::FromBase64String($ScriptBlock)

    # Then decompress script's data
    $InputStream = New-Object System.IO.MemoryStream(, $ScriptBlockCompressed)
    $GzipStream = New-Object System.IO.Compression.GzipStream $InputStream, ([System.IO.Compression.CompressionMode]::Decompress)
    $StreamReader = New-Object System.IO.StreamReader($GzipStream)
    $ScriptBlockDecompressed = $StreamReader.ReadToEnd()
    # And close the streams
    $GzipStream.Close()
    $InputStream.Close()

    $ScriptBlockDecompressed
}

# For each scripts in the module, decompress and load it.
# Set a flag in the Script Scope so that the scripts know we are loading a module
# so he can have a specific logic
$Script:LoadingState = $True
$ScriptList = @('Aliases','BitsAdmin','Helpers')
$ScriptList | ForEach-Object {
    $ScriptId = $_
     $ScriptBlock = "`$ScriptBlock$($ScriptId)" | Invoke-Expression
    $ClearScript = ConvertFrom-Base64CompressedScriptBlock -ScriptBlock $ScriptBlock
    try{
        $ClearScript | Invoke-Expression
    }catch{
        Write-Host "===============================" -f DarkGray
        Write-Host "$ClearScript" -f DarkGray
        Write-Host "===============================" -f DarkGray
        Write-Error "ERROR IN script $ScriptId . Details $_"
    }
}
$Script:LoadingState = $False



