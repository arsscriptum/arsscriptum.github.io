<#
  ╓──────────────────────────────────────────────────────────────────────────────────────
  ║   PowerShell PowerShell.Module.FedEx Module
  ║   Version 1.0.2 , Generated on Sun, 13 Feb 2022 17:25:41 GMT 
  ║   Description: 
  ║   Current Git Revision fb871b8e14199c3a2df5c151999652ffb6003346
  ╙──────────────────────────────────────────────────────────────────────────────────────
 #>


# ------------------------------------
# Script file - Aliases - 
# ------------------------------------
$ScriptBlockAliases = "H4sIAAAAAAAACuPl4gIA1Uuj7QMAAAA="

# ------------------------------------
# Script file - Auth - 
# ------------------------------------
$ScriptBlockAuth = "H4sIAAAAAAAACuVXbW/bNhD+XqD/gVAN2MYsOwmGfWhhoI7tZMFmx6udvqAIAkaiYy6yqJJUbLfIf98dKVkSo74kQ/dlCsDI5N1zr7w7PX/2HP5O0jjQXMTklGn/hIXj7SDVKxZrHlDcX4hbFn95/ozA83G4DiOmj3kc8vimNU+TREit5iuRRuFMioAp1b60tAmVdN3CN3jsloGY4T7TTLYmNA6pFnLXbyxppFiHvKVRyk6kWM94wiIes35DyxQOfmdRMgFwesP63omQAfNyOQZUbbgOVpcNc2T32yDUvjUuFJNDycLPpG+sHCQJ/kQbQS5p7S3PCe3J2aidAWQM3+WvHBTsw4jD1tkI2PdQXZQ1BU9UaOYskExX6AB8yvRGyNsCutXuzqhSsBlWvdt4w25mVK8yRY1SExGmEYMDrrTc4WlBz5etgsdnn4jngeO+EL2SYkO8WGjCY7I2CN4rArqlMiav7guEd5Jr5r9l8looRrxIiFtkyUG9km7jLWig0LgTDHdFCxs5o4I9BS0Kgio7WpabYzKG+EZ/by+U+OhZ0qQBZuSVxhRuVj11XxVvwduuzKnYLDggWaEjqhmpp4DAiThE7YYivmNSL4Q/xINWTtF2GHFvvE04BLVg/nHTGLKaC3qlAalZoDtyRny5RJ9XFfVr5FcZncA6djpwHVJjTo2IDjHqGKU81yEYpaeHt4qGMTWi/EiTAzeuRt5FAtWHvVsZoYfEz1z1kNLxBFxcwjBdoARmWneIBTOZX8JV1mrHUnyym2TZq8elzLxncBMc3R1t9re37AwyOh8PpmT8/my+mHvVpCjBf5xrCUZcNi5kBD7wVlon6mWvRxOufAXV+Vpsu0soOttuINY9QaEx9IyA8rX+ndGQSQWXgwLIa0ddD+6DhqrlL3YJ81AKTZIo6y29rb/ZbPylkGs/lRGLAxGy0KtVtnEswt1XhNxIGusrDRLs7z5pBqaeXgVFnXYyJCPgpoIann2driVUtjSXCG2xrhKnUNVjTM4Cdd99nJKfP0mpkj9geVT1L3vLtFlV46sLycs/jTgZVWnQ1Q5N7n0HDBQd3IBae0Kn7ewJqnxZzpQFlNKoSjtheiX23jHBnZ3PF044QdAxVTwAuxVeTEDE0aHkHPsPh4Ks5drSpM5iCCR66rcDe+DcsLP4DlLef8eu37BPKVMaXBi9NF7zahn2rs+CkFHBTVWJiIGiTzJM2NGZea8tbUaa18I9T7d8vb+lZgnSgICi5n+mxEfsYViXL2t62wMS4yE7BVrKnKk7CPOS3qr6EdpcZsNjO6Mj7Rt8VcKiseaC0yjqT9nGP9NsnTWPYsjBTaxF0IkkC3D8JH5pbDTcIHT+xCHDt8RZBJ+KCYUFghBeiRJi1Z9PRXbnhj18rfetFKdZ3Vc+G7K8AxSOfW8mlKbRz/5esF8FT/9cyPqeVXYITafzkyXm7oFAtZqD42aneTyEZYJvU7P8icsClzkuF7CcT2GZjWH5C4nnf8DyYdGsN0WKOx4H/60hF6jqcFCv0VCkMaRjWaGissxXPClKDn6rPRhKTlPozX3SwpuM7+0url+dXprfmV4Cq07v7rCXmLD37jJTSp2kMUgBFdGuGZVMkib5pfx99/DLOCse7R8eiF54Wz9IlRZrJn0Ng4ui5iL5PDTjkbHbmRi9IBuidN0Q9bcS5YEMH1RUSP7ZEJjPSbSrdlJ4gYuNGZknLODLHXz+MWLmWWDerHiwMjsJDW4hLQhXRAtyzYiCICYs7BIHbQHEykBxFlogZa48wQ9KYES0IJUSBwcrRxIa78x7hxwewMtOEbqE1H1AWyvNgOAYSTVZg3NRyAd4/MnEH426PzZFBlRKDoMXlAMzZZyM3p+6Q6NNopzEy5PccT+kl2bnMr+TBXm+49DbhCyR7X+7wNm1wXfQ8Ojg6Mg/OPIPf21+fQx95Aj6mPHzfzh6no7//eT5jenv/tk/rUdzqpYTAAA="

# ------------------------------------
# Script file - FedEx - 
# ------------------------------------
$ScriptBlockFedEx = "H4sIAAAAAAAACt1YbU/bSBD+jsR/WLmRnFyJQ6VeTwLlQwimjVqSCAeuUouQcZZkheP1rdeEFPHfb/YtXicOUOCquwtC4N2Z2ZnnmZkdZ3trG36u8iTihCYoiBhJ+V4n5/Q0HYccDxmdMJxl6A7pzxvUH/hfh4OT0faWeP6TEY6bS7lmByzdEL5ANW3MbI0IjzFqBjzkeba2ewy/4QT2h5hFOOFdOktjzDGq141owHHaz2eXmKHWUn9EeRiLnayBfkPvdncbyi1yVaXXjHmV5t266Nu399tb9yVwPmLeBGSmlJEfoVj5hMMxGL1bw+RbdzYG5w9IMibJpN4418uDnKc5Hy1SXP8WLDKOZ17AGYicG5E0ZOEM1dWD1BmKFQCCWYvicxwmQBBlC9RGNc5yvFPePwvjHB8xOhuSFMckwU+VO1gAJylmfNGHg41WoWRcVd4FXYbHwBcJY3tdRwdOAqkz2PdETs0kbF6h0uEQ/mXOMWBUK5aVIc2kBobRSOZhcYh7EGYkQne79y5qXtmg2S50aXIDwZzvAeGggD+8V5CviNsqI3zLPT+JqGAPFDtBt9fzgP6DBcdZhaL41F1wZO/unXLGCsY7zTATUO6UVsFcH/M5ZdfFYr3hDcMsg8WxDt7+NN4gPxk/z8sV3SeAojXKIKvte7WlKYEyUc8b6mOtho7w2L89ZbHhcqVagjxNKeNZMKV5PB6qQ0r1UV0ey4JoqzRfz2yz8QnHqe43bWcAQMxFD4OWASHhDKhwdtCQZkR43N4t5TvYJKIv9inv53E8YP4s5YtlhassUiVd66iQixzWnNYuAXEaAlJQXO6U8zTba7XkggepMCbci+is5VrStuB8Pq8SA8/zmLdd/ZzNCY+mqI6MG/pwu37Eia5YM9qi2OVxb2EzJa2bd60wEvBfcHqNExfdW9ozLHQrtFVohQktaOuC46IpZO5D6jnUTStaQDOOwgyIbVlaZXNC4/2KLdddE/l9XWRN5kOFzLrUHw9bGuOrUGzcIT5ldI4cktyIxEGh5MJZCssLRvzDMM9ZYixW3TyqagCSol30DuGEf6qGrsI4e1kRVRZFb1yuBRHND4EgxIdvvWBK0hQEvU4U0RyujRHOOKT0Kk5SbSNMnTT9n6I0pHPMgimOY++YjvMYexI3XfToCSAJQBVKX+jk2cCgunFtGMo+tsReuXWCJyTjbCF27TnxeHCNHKlCYAYU/zj2dncaJgmOzTD4uOSJqsA1wQ2JoZwTVdSZAPjoFeJXJvWoVK/5tzjKxaFwxXJxQwegCo9i7MUNTZpWVT60kSMcaqony56Hujn0vRnSTKv4yxRLpUfCtbl4hYhhskZrYaIm/gvVErgSUaNoewnliCRoJt1w9o3XjoP2TQd8CX469Zya3z/bG7BJmJjB43P39Ltl+btEQ1yXVRiqHC1DGFitJMARiP6Lp5VnTygjcavvmOVf3OvUhHJeO6Lwwmd7YCoL8vapzUXmpJEXqQgp9nge7psclDgMlZNwnGyR5hAZLryWCsuOOcNBTT+BTZgG7PnIfmGRLpUMN0ztFV3sDLNLCvOWIwVRGDMYmRcooskVmeTQvnXP0wY1VrLWjgQbDWucK1J6v1gs5gwZqMjjNurj+aPhyYIsR4eaSlhFhZriPRa5mcwld3WM2dyUXl5RRfP9iRR5ZZLX6ZWsiEoQmVcwoNFSHj7/PBtdabFErOrJyc3ekX/of73odLt+EIwGn/0+asKbf9GYjYlqWWPOSAm1jZ3xUA254u5KRLL8K/rjR8KR8ah6tBK7L+w2NXoNYsEanzaVjn4HuMiNN7ArztYV/Q0nN4TRRLzQwGs4GPOLhbOQkfAyxnX30D/qnH4ZXSiuTgP/pN859t0dbWvHFX/cRpk2er2x+F6LtOeVoMQebnkh2YPvIcwXTRv7zyqI0IN8xijT77S9SUIZTAWrYlZRyCOra0BlwmoFGcQ/9kZLvB8ookpxmG5WLgIh+gRrtoWNpVjFa4AZXLjmW9pfSqo++mdondKMP0Cn2bbw04dUI6c3zQv4BkJVCQHAZ/7JEwgtiT+nMRpK/htt8ZPG/Fe0RsOvaInm3Je0RUWSaIpLa480xu2trb8BUieBv/oYAAA="

# ------------------------------------
# Script file - Helpers - 
# ------------------------------------
$ScriptBlockHelpers = "H4sIAAAAAAAACs1WUWvjOBB+D+Q/iJ5hHahN920J9KHbpt2ybdJNsoQlGKrak8R3iuSVZNoQ+t93ZMup7DjZ4ziulzxY9oy++Wbm88jdThf/MaNKkcsV5RzYgxQZSJ2C6na23Q7B3x8tJvN8rrRM+TLyrJ2ckw83t9MP1nopuBIMLgUTMvKmqbZr43ZPl8A1bXe9B6XQvnO+ovKvG0k37d4DKYWs+Y4haXed5HGM2A1gAH4E+QpULNNMp4LX9v0AxsQzbnztdrwbJp4o6zt1Uug336tb1O9zePZ7purdziLnscElM5lqCKy3zX5rCLm/iuI6YaA/pzzB0vuTPMuE1GqyEjlLMJDJrxeVvhmVdO2X62Lvg3kAGqR/T3lCtZCbc0/LHE4fhEoNlfOzanOtwZZTnUqRhVmU9L8IpcnJ3PPbqhHam15ETkiwIAe83kTSI8FQDOH5LuWwH6UidAzLVVGvaNPhmo9B5Uzvlfz/14FT1/Sc6ngVeTMqOfo0mpIu/MpCAvhJvGvKFPTsK/3ftW0vEhl9Jcfh3Nd0H/AVMI9DacwuxsPj4G/jogW6vPybejukuILG9v30VhPZZKM0rEN0wQTWOJjDi1yLNTW0y4KNIRYyibzyupOauXgLIdG1FCpOvZPt2esj3358PansKbDEzEO7O7zOGdt8yylL0ZQU+LfJaWUdvMRQjNtwKiYFqJmXBVJpulfLc78e1XSlDNN7r5E0H4zHo/E/115NbrtEH/kjR8RrIWEpRc6T8gx6O4Cs0HYiuwEdfNE6m8ETDrUMzzMkzzX2dHecNwRVKWE+ynWW6+kmA39eFj46qCurmCHosBEtIp5z1xhKHvYL6HoMNAFzknocpVAZtdyUC+fl9uKSfNO3nHDE94unJOBQC4vlRbkT330W2jrcAV/qFQmWmpz1rFwaUR2qJrALgvWt1pPCoRLnbh/wWJjCmg8AW6YpvOhwYJ/jN8D36fWn+i6TS8CFJlXl+/1bNcTURnK2QmFMMhpDazoVrJtKSzp/lxrmV90dD1eHL0TYUr5dp1HrwejpT4g1CYzEhjiWiOVwOwonrndwIZe5GUN3Kb4NvoU6fePfLLkjEjdsaC5TMeCJ26QaVQk6l3yHUDsGFimnOKj2NGl65cjOjfhbOVlil0woaJCyF3tudH4Bq8c+OpsLAAA="

# ------------------------------------
# Script file - Parsing - 
# ------------------------------------
$ScriptBlockParsing = "H4sIAAAAAAAACuPl4gIA1Uuj7QMAAAA="

# ------------------------------------
# Script file - Requests - 
# ------------------------------------
$ScriptBlockRequests = "H4sIAAAAAAAACuPl4gVCLgDKK+/YBwAAAA=="



# ------------------------------------
# Loader
# ------------------------------------
function ConvertFrom-Base64CompressedScriptBlock {

    [CmdletBinding()] param(
        [String]
        $ScriptBlock
    )

    # Take my B64 string and do a Base64 to Byte array conversion of compressed data
    $ScriptBlockCompressed = [System.Convert]::FromBase64String($ScriptBlock)

    # Then decompress script's data
    $InputStream = New-Object System.IO.MemoryStream(, $ScriptBlockCompressed)
    $GzipStream = New-Object System.IO.Compression.GzipStream $InputStream, ([System.IO.Compression.CompressionMode]::Decompress)
    $StreamReader = New-Object System.IO.StreamReader($GzipStream)
    $ScriptBlockDecompressed = $StreamReader.ReadToEnd()
    # And close the streams
    $GzipStream.Close()
    $InputStream.Close()

    $ScriptBlockDecompressed
}

# For each scripts in the module, decompress and load it.
# Set a flag in the Script Scope so that the scripts know we are loading a module
# so he can have a specific logic
$Script:LoadingState = $True
$ScriptList = @('Aliases','Auth','FedEx','Helpers','Parsing','Requests')
$ScriptList | ForEach-Object {
    $ScriptId = $_
     $ScriptBlock = "`$ScriptBlock$($ScriptId)" | Invoke-Expression
    $ClearScript = ConvertFrom-Base64CompressedScriptBlock -ScriptBlock $ScriptBlock
    try{
        $ClearScript | Invoke-Expression
    }catch{
        Write-Host "===============================" -f DarkGray
        Write-Host "$ClearScript" -f DarkGray
        Write-Host "===============================" -f DarkGray
        Write-Error "ERROR IN script $ScriptId . Details $_"
    }
}
$Script:LoadingState = $False



