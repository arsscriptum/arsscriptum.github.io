<#̷#̷\
#̷\ 
#̷\   ⼕龱ᗪ㠪⼕闩丂ㄒ龱尺 ᗪ㠪ᐯ㠪㇄龱尸爪㠪𝓝ㄒ
#̷\    
#̷\   🇵​​​​​🇴​​​​​🇼​​​​​🇪​​​​​🇷​​​​​🇸​​​​​🇭​​​​​🇪​​​​​🇱​​​​​🇱​​​​​ 🇸​​​​​🇨​​​​​🇷​​​​​🇮​​​​​🇵​​​​​🇹​​​​​ 🇧​​​​​🇾​​​​​ 🇨​​​​​🇴​​​​​🇩​​​​​🇪​​​​​🇨​​​​​🇦​​​​​🇸​​​​​🇹​​​​​🇴​​​​​🇷​​​​​@🇮​​​​​🇨​​​​​🇱​​​​​🇴​​​​​🇺​​​​​🇩​​​​​.🇨​​​​​🇴​​​​​🇲​​​​​
#̷\
#̷\   Generated on Tue, 08 Feb 2022 11:47:29 GMT 
#̷\
#̷##>



#Requires -Version 5
Set-StrictMode -Version 'Latest'
# ------------------------------------
# Script file - Aliases - 
# ------------------------------------
$ScriptBlockAliases = "H4sIAAAAAAAACnWOSwrCQBAF94Hc4W0kugjoETQGUfyB4r7jtCTazshMa65vVIKISi/rUdVxFEdLrtOhVBSQLunMMIJ0R3JlPMhout3MXIF0zGHvq4tWziLJPJMyCJZrGFdbcWSgFE7Jt7A4tsIJayts4IexQdCSIVVQuAMeMzx3XecxmoXeD7MRY1t35s4XYeV/gWy1WM/zbQ4SeZbeBS1JUdKteZXZYtDvd6CebDiwZ9N0XxfdAW9qnAguAQAA"

# ------------------------------------
# Script file - BitsAdmin - 
# ------------------------------------
$ScriptBlockBitsAdmin = "H4sIAAAAAAAACu0bTW8bx/VuwP9hsGVLMhEpyUnawgYTUCRlM5YogaSjBpLgrMghufVyl5ldmmIdXQqkPfUjbXopkEOL9tCgaHto0UP1n5Sf0PfmY3d2d0hRlJ0mhdegtdyd9+a9N+97hnfv3JX/BlOvFzq+Rzo0LO00u52WHzqDeW3c33M8+uLuHQLXMXx1abjjeH3HGxY608nEZ2HQGflTt3/I/B4NguKpGDuxmT0uiHsOe4gPaEhZYd/2+nbos3klF7Ip3fjAdqd0l/njQ2dCXZhOPj/0AwdpqmxtxHjwekTdyT7MZQ9pxUJiyfv+GfEAvVUkp9qcQciA0NMcvG7B242XQ872MnJq/ngMCBcQIt9u8KfXUTOw3WAFcu4VTTNV2XA6pl5YsSw1U1H8yXmkQh7KZQbJBDV/6oXkAXEGBXhXoh+TreILMmNOSEu1ke151JXsEavlkx8DiAXDGQ2nzHtALgRaiRyRVuv7zValMIQ5eoJhcuaEgd0fO16ZntNiueNPWY9KkNZBt7nbbLQr+dr9E1CjIcgiOOnMg5COu77vBidcGR3KEDgvoJBYxSOnOZ8vSjXF63tWTIlFNkGrEwpNlEoQS62JRVpP9vYEhgsKkr8ltog6ifLunYuUqbVpIFehQ9lzp0cJTLmmpZFCEZdg2QrHcoNFHoa4yDGHYrVHfhAS66jabjVbDy1SGgCNfVI6I3WbPXvI7DkptfwWnXGmH5CcXWlTu196hGAlIGs8AfDuyAnIzHFd0rO9HnWJDbchs71gQBkqJ9cggmTgTbFMqoySuT8lwRRuCvPNVvE9VDAk1SYlzw/HdtgbEWsOVvVCqp3UuotY9dZXwE6POZOwTkHiFCSXz8HKTN0wgHvLkmNqI8ft45PCsOcAs3Y4IsQChX0SUAb2UKo7jPbQcIvl3anrojoI0F2fNezeqEByfYcRx1O4dPHnOtMzjrICrszxBHo+3jqpTiZ1O7RP2r4N5A9P9p0e8wN/EJ60aDjz2bOTuj/zXN/uUyapxeuIryhfGut4B7ivIvdc504JX1tcVL6+0ZqaoWuPGrXHoBARlRH0h9R1/ZkRASxelwah5ESxx7925xNKar4X2gDBdDGkZ278qNnpdspwJQhO+M7b85rGEFHbOAdUKWaTYLmuH6mNphgxv7uOS/n/4NuJ9fF4yN4ov2EJFcGAlUY3nnAIwAZklrp0DHZvszk+TOuVujT9AmND/VJEpUX7ckQVu4t0cOCzooEjJUvlhlebjv3ntNQELy9IL31A2ZkfUAIC88E6SalNe1MGD0oNxnxWFW4TNcfxppS8/e67kcSS6C9SYlX2/KZwi4gBw0Yk7lLb1ghMe/+02Ej9oNFpdYnQzojPh4xST8MiHZSMVzdaWumROqE/gfHH4tuO6/eend6/X2PUDmkh79GQBDiCZ0Cb83wxBWyz8DpoHILgKVg+OFJsM4aE11Tg8K7/Exl8wG/hVxC0A4kM4XqmIpQuznaj0+h20b90HzWIFmc1XcxClcyXUetS4Zuhsos3HZfSCdkWX8xKjYswQaXmYg5EpOYuSUA1vef+MwCTcaakCSuxjjhiMgU3wBOFMnyPhKPk9kDS8xbcHenECP0llk4CX/sJhUzjwTLyI5s8mw4g/pIBqFtwM/J1bXgZXNR9j15DNVfe2wodlfsm9OpKtlzwgFkKXuYfibwOzVtmXrfI6FaqnYyp/xPmbqxUWxihUVBQNKyBoeo6dlDIT/Ib+QkEv7wRfR2SAsezUVAYIdebCWoiB95SSMQLeYgVdMggw+3DxI+c4Qj+tHw2tl242fNnZjoOmePDSs8rlhgrFUs6spDN9ezs5jklB2tWcC3Ke3YQNr0+PT8YFPKb+SJ5U3kcPgqGyMDAR0Pq0OE0FnJNSQ1emAxzHcZax7LSoV28g9z1/YOdp3mYIUKbiEhJfKm1WIQ6PUy49zod2GAbKvfEN9fCablt+iVnIIkA7YhnBwtA+EueTEa5d5Q56AlDc+iBipBPyME0LLUg0JJbESoFuzxfAPFC/hRClZOG/4REeXGRmDK0cMQgp7Z2fRcSetL3aUCgBCL03AlCLb+XK3rjSY05+DJCuiNKOKCtyu3xFCLwGSV2LPgyQZkE4LrCUQAjKacZKj9/Rvvl5WTfWv66XudUr6CCSqq+QC6SVFBzpdNqHEFyd9TaO6jWSbfaebygnsqmHToJ5pDG0yYMacpieNOKq71l8E/NPoghmbiQzXb1qN3oPmm3yKbnz5g9IZs9no1B0SIRxahEVCvtQyXuBLTng8N6Z2vLJAL0Be9By8cY+pBKMUm/TIAqoMy6IKjy5IVSkUa7fdAmtXajyvM48EGSseTSYBm7Gld2v4+JimIL/sKq45+UNmCb4Do+BVeqtrAEX/cFNdaKQuCetNrv00W8V+t15Hy3uddApiOWVWMInDv+LbfpxLV7tGDlrQ3oWK0lnEz7KZaS0ncrnvnrERDQRARRRFK1QFCi2VcDRTloJSS1Ov845zjm+uthEM2Ap5QLVaDTrbaz6r/e+h62mwftZvfDiMkoX1mZK90l0hmSX+ERVbkfeNLwIM9Bg5bpAxoZySs+8rEvNXhhRQ/ZItvw0aQtnUv8QHTsFBn4nMulh009vckaCwbcmmgdCrq00K25t5E/KzXOe3SCRNUpRDKoMnNPoRiAN7BUvWdZErwIhaEfi6UCFjlR23TtbQ+wa2Me+fI770lXE6TwJ3Ubn2SSOwkl/n5CZiMKsRukF04D0Vbvtqutzi6oeKOeFyurYDXt1pVtOpY4t0zTa+/5kzKXwUUq0ZVjpESSJEujA3nwMTMH1DEQBCtaG3XNrC9uncjHdwNIJLHXloOl4K02o0wdjN04pNysp15hz0+9zGa8OcmHHCCWITVE1Qo4IGWVmWxQ4csspCndywFz0GgXCQi2vqU94Dd0H+AmXmxdkPvkxfaFZQJ3qOiQA/8bnFHDoP1gWCkkZ4KGjYTVwqG6jLaAWBZ1NiN/qHuT2sH+4V6j20DSTKQbffMms2fSb8QILIFh0eypoJGOMEsHR138Pm/SkErlXbHaRoodVimgqYv2qWgiRtl4VrM4UOMc24kJzafnExd0mpkVX10gGICFKAQzZN8uTO4j/3SR9vVCALxIA5ed9MiRP854ytv44zXNX+bjx6enC5TEEL8hCYH2ooAHIywISLRBcGyuWySlA0a0p5AHJvaCMh40U2B+B2UDjhCqrOn4DOKzP+DBwYiETyTcbCRocRMFZjF2mfx5dbeG/A9XamUt7kbJLDbRnPkal5F3S6Nc+haLakxAkquAoKYl6DzvQbNd9B6RCoVWCkMECSEJ1aFUcVw0jOTuqY4DdqD04JJx/dGGdMrha05ew7ahqJCDVnHySxx7UgTYPNc3yZUW5nrB0o0GPibgrWDsi2G3PJJP3w+e98SQxHPUIMPj2dSe4r3aygnOeKMZdkYE/rPUzoh4WlyhVS0xJbrSwFeqay0QSV0geU59PvUQSU8/0+hOyxQKmVcoVIE/K9Xkc428/xfB8i6bQa5HxpQ+MxpsDebgGRc69+ixzMfBosSGiDpNoazSqyw47ZGr+0CwchGcfil8yWzKD+CG8CIALoh4/DLGalPGQOrunNggl+dUnPiA2tQjlu5CY+KEz+R7bbSfV940QU5qiO5dF7QkEpwmZAHbhEc280DQqyLh3KclZEJjPhRT9/kJl5kN9V7oy51XXGNpDMENz73E1qTrjzldMK9RWjy8u6ZJaGV4IRkET8omXT8ZKm5da78ByYWypldUpd8wb5FAcSJnsPEF4VsfifEborjedQ6y0TxKAVcO4NeG8cjQF5fzS7Ki2ybeuLh78J2fX+BHCSEFdl3KFS8oVxmcZsP3EF08OosqBCfOuqNaf0fsnGO5j6QkameNTJiw6Q18lKaAKHcmrgMblETv8xI1TmhVJfquZ+iGcvaw2u5gc5FXhQJ/xsIMYInJElPH0MkmVdpCmnWNyOOt0wUjVZdbDdxeNBAGSH+ujb6XHu36ciwvPLoy3vGzX4nGUnJw1w9tvjkUqHdLBu/Mwxti5hAa5qz0tV5XLPYSmMQPTB2X5VxGwnkrJZzreY5A31kKapJABPp9A6jG2vEPTyFEgft/0nrcgi0zY0vpehlq6LLgqX3Ci2tUb/kGSwIk6l6v1JAHZz1RANFGmxGvdFWZytkMxvvtkEaX8tduiGbG8P37tDfKOiXpu1QXwOiR0kwIqiTo8dsmFVpwmkMDy6hPolkt2Iy2F4TEFm7WitHLtjCEn9J2MTQ3s9IuhskIU9ZlspikWhsoxhBTho1DbjdF40ZGpjkWu3GZXArv32gTsdG0Cx/J6tOURl0fI/WNlSTsChsq1zX/USkPOzt4FidKxbDDz48ZBI/pvJCXOVcyfzcELlACKB8G4uCs4FZkwyprS3GuUgkV9k0tkGTCp3GR6cVILOnyLj6xf9vtoXWPqi852W9O01c7g28t/XGAuaS5xan9ZU33+HDmRaRfqe5FzL+yX0XsjasHcbv+Wbub/LLoVR1hi+qXNZUq/euWRjfafo5OESQn4yuiWwXsx6sl+V8vxUuWBpxOfrIPG0c69qWFLEad4JslhFfzgy8ZkAuJYrMUKYy8UTTw80x51UFVpxW1H3MhNkwoRTtd8z4ygTzbluliORWEsyPvqZGm0Cwo4a+bGqxewGg7s3HxDtzD6+2tLfIGKRAkZxP+vxf3DfQDYh95lfUu/dQ7R6tjvbr809Xl368u/311+bery7/y+z/AQ3J1+SX/8ke4+9fV5T/4QHjzz6vLP5tOxOtIXxahyV+WcHGear+NsIXn0Ad99cVn//nqi9/8Fj4/hc+v4PM5fH4On5/J5/j304/CBb9LiQ6Yy9/tnG1fxyxM+RdA+Xv4/E6i/5xIOn4tHyItv1h9znsrzPmlRP9L+HyG6OXcioZPyXdXnhD0MP2Tk2R4xMSlVHXd5WnK6wMrkeG/PrDy7TywMtPMIh2AtUDEfxeehV7j1MLKR87MP/bVkqTXR8uiBW42Wt2nvLD9dhwvi+l9fcbMbLLaiq50zkym2N/yM2ZtWSisecJMgsvzZUb4NTzWonNWd/4LwOC92PpDAAA="

# ------------------------------------
# Script file - Helpers - 
# ------------------------------------
$ScriptBlockHelpers = "H4sIAAAAAAAACuVZ62/iOBD/Xqn/g8VGAqSC2ntfV0hHeXTZLYQDur1Ti64pcSG3weYcZ1u22//9xo+8Q9pl6eqkCx8I9nhmPPOb8XjY39uHz8y1PA+1FhYh2B0yusKMO9jb33vY30PwvMqZEuOXHmcOmU8NPY8aqHzSm4yb7X5vUNY0LUo86uIWdSmbGhOH63dJ7Po4n66PPc+aR5Rti304ZdY6n7rDGGUJ2hG280nH/mwGvFOMMSYFnNvYmzFnxR1KEuv+xK5L72Dh4/6ecerSG8s9jpnKA7rLjOmmx8cE31WqwvD7e7c+mQm+6II5HNc0td79g1Ao9rxCA7Pzx9AcTeBHoO7SdjE/cYgNnqiM/dWKMu6NF9R3bRAq9lqdKtqVxaxlRb3LtUMxgDlmlb5FbItTtm4YnPn4YEg9R6jVOAwWJ/yt9Tt4itet5XoxZke5zExpWMtVU9Iu4kUZ5A31OCpdGpU8+9b1j+oUlVDtFm2gijBXRbUBHeC7M4dgJcW5rRjD8Qn1iR3uAPhSwi2HeO/wulIO9CtXqzoe0uoF9ihSIg7orBoZjoHQIpZxKIPZBI9HDAbflZaapYT3ZqyOsOe7PA3VfMzK5z8GXO/O4bPF1LiwGAGaFAoFPvQMquF/kNEVkN4EhJfDaUYSMt+hYnYJeGQYFiHl8qI5GhQzjzJuDmv1lQ3jLRCoobcJfFKNh6cxh74F+BKIG689jpd1IIHdLDHh9abP6dISe1DWG+EZZfbUUN8h7sSXcUsZkCrUwilSejh8vCYPR4+lYN7Bri3OF7263vVdd/27b7kOTNmSf88+CGY79zMsE0p9QseSqTh/JCc11ffmjUpSqnCREqNJvw3QE1I6o5E52h6ICeyFG70m1wQ4dinDcyYSvzrTowNdoy5E3CnmtTa+tSDNtekdcakFZwVfbEx5MfxtC7cw/xh9avsuHgDihLc793jmqzqEcHzP62NYCj/H3OK4rmj1whGeCy0FeozO4P2xyeYWcT5JAL551zq/irEuRWvgyNPCyjl7LoeEIumjRkXYpgdA1/XNGtWk0FB6TTKLMa7Wc9gqrgxzn5GAefbYEbIGlAuEs+Zq9b/wgdrvTK7Qe076oFFuHV+B/nNQ2btSWWdCqetdBaaq4/ugyIbTbII9XgMZDoT5+r0FBXjGZR0CUwmfxc6J0PXSHV/IKEzAiSPiKb9DTNcCtLylN5Lrw4v5HQW5/nIVJvqoqjjYlPMvwQQOzGAw+wCSsck6yxVfVyKCoAaBvFwg4WgHEoSpi2R8twMZ58wtEvH9DkSIgPK9AzlYIOqHXVhMx0rRln7cgRy4SXKHyGgWIVIk7qcdiBsyh8IZuC6S8/NB+sL2BYJcKsR0HRd7E2YR7xYzbEOUFMj75evlTSi3XCm0WNSvXy/qZM2fv7Wjwx3tTUptHGaSmy4SgxcDsqHoMQzHLd+D4tK8+RvP+PS3WLoOnl47PQInWU9XnfFHp+kkoRjMkkIKyPKEwSyliuQUpRrMEqfQFJCnhrPrIlQkxETD2SUp7wZLUsMbREmqrCg5nF0ShGLaXsF4jid0TkqQB4NZ8lRqUeSpwejwTZ68gKN00dsjgGmA7CdcEy09Vac8vNT1KRkrBRlT1ERlcSRszzEwYcgudeUX1UXwHrQA0lqIVkCpFK+LxJOj7GWHfHQYJeIGCJ0/qJm61LWV8EoJ6D9wumo7DOIW1C5Vn2T4ljpE11npyaj3+lfbvBicmc32WG8uxBSUUqJcD0q1zL7E5GS9wijUSd6UZlDcyZtWU6NjTuD6hD4j04eaHNJZzB/pzoK2oSjdUdaSn5GsSMV7FaUNKt2xYPQOlZTZkE0h5ghwwvdQeOqaOZS8hVBlCbll3fXDrFCRyQIjudBic1+4FS0h+aIbjKzIaHWVxQD9fOEBJZY6W+J2ie36ZrUf08BLgHUD6uI06kbWosslhAJc4XTZDAMriFiQLS4Deb6s1sfUBz9nTJhVwRAOz7NQOrQqUNFT9yNWhi4ZY9lFP275jIHdxODVjUNK1XqUm4rYxaCfmNmwy4yRs+gAp6gLUQ7XCBdn2LpN9H6D5y7dM+sNTnW3Qv8HkdvHy1veag4G5gR1e4M2XGAmvW6vM0LN4fCs12pOeuYgZBq0KJ4yVjm7/+cFaILPN4nOTRLTLtg2KkUoFsVc8BJHyNZ3/m3v/XJdNkBgtIHGK9cJMKpJ+use+UhVX6DeX+uADwMpv697TRq7feJQzxfZMgfd3un5SIIYmV00NC86o/GbztkZ6pvt87NO3NQplL/O5/mCm1AwyBMa5BiFMniueSkW3UnF0etk7zF1/kiJ4t/MDbLiTR8EXZ9CWa9Tfc54ND0laMeWlH3VGCBiyCaiRoATISxAoi6RLC+q9eQdI1gQ0Bf3F3NblaimulJ55pcy0zZJ/KEFHs/yzBRMpa01zmvsRRqnnPgcdXMYJg+F7XWN7gJ2qOPR87SKLY3kP7FmDLeSFVRj+jA/EKcJGH0e5PBH2ORsETsL1EGKRU1TMf5K/W+59y8M9OLJ5CAAAA=="



# ------------------------------------
# Loader
# ------------------------------------
function ConvertFrom-Base64CompressedScriptBlock {

    [CmdletBinding()] param(
        [String]
        $ScriptBlock
    )

    # Take my B64 string and do a Base64 to Byte array conversion of compressed data
    $ScriptBlockCompressed = [System.Convert]::FromBase64String($ScriptBlock)

    # Then decompress script's data
    $InputStream = New-Object System.IO.MemoryStream(, $ScriptBlockCompressed)
    $GzipStream = New-Object System.IO.Compression.GzipStream $InputStream, ([System.IO.Compression.CompressionMode]::Decompress)
    $StreamReader = New-Object System.IO.StreamReader($GzipStream)
    $ScriptBlockDecompressed = $StreamReader.ReadToEnd()
    # And close the streams
    $GzipStream.Close()
    $InputStream.Close()

    $ScriptBlockDecompressed
}

# For each scripts in the module, decompress and load it.
# Set a flag in the Script Scope so that the scripts know we are loading a module
# so he can have a specific logic
$Script:LoadingState = $True
$ScriptList = @('Aliases','BitsAdmin','Helpers')
$ScriptList | ForEach-Object {
    $ScriptId = $_
     $ScriptBlock = "`$ScriptBlock$($ScriptId)" | Invoke-Expression
    $ClearScript = ConvertFrom-Base64CompressedScriptBlock -ScriptBlock $ScriptBlock
    try{
        $ClearScript | Invoke-Expression
    }catch{
        Write-Host "===============================" -f DarkGray
        Write-Host "$ClearScript" -f DarkGray
        Write-Host "===============================" -f DarkGray
        Write-Error "ERROR IN script $ScriptId . Details $_"
    }
}
$Script:LoadingState = $False




# SIG # Begin signature block
# MIIFxAYJKoZIhvcNAQcCoIIFtTCCBbECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUYxB1J2UC+DrpKJEdcbb1XBFd
# BG6gggNNMIIDSTCCAjWgAwIBAgIQmkSKRKW8Cb1IhBWj4NDm0TAJBgUrDgMCHQUA
# MCwxKjAoBgNVBAMTIVBvd2VyU2hlbGwgTG9jYWwgQ2VydGlmaWNhdGUgUm9vdDAe
# Fw0yMjAyMDkyMzI4NDRaFw0zOTEyMzEyMzU5NTlaMCUxIzAhBgNVBAMTGkFyc1Nj
# cmlwdHVtIFBvd2VyU2hlbGwgQ1NDMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB
# CgKCAQEA60ec8x1ehhllMQ4t+AX05JLoCa90P7LIqhn6Zcqr+kvLSYYp3sOJ3oVy
# hv0wUFZUIAJIahv5lS1aSY39CCNN+w47aKGI9uLTDmw22JmsanE9w4vrqKLwqp2K
# +jPn2tj5OFVilNbikqpbH5bbUINnKCDRPnBld1D+xoQs/iGKod3xhYuIdYze2Edr
# 5WWTKvTIEqcEobsuT/VlfglPxJW4MbHXRn16jS+KN3EFNHgKp4e1Px0bhVQvIb9V
# 3ODwC2drbaJ+f5PXkD1lX28VCQDhoAOjr02HUuipVedhjubfCmM33+LRoD7u6aEl
# KUUnbOnC3gVVIGcCXWsrgyvyjqM2WQIDAQABo3YwdDATBgNVHSUEDDAKBggrBgEF
# BQcDAzBdBgNVHQEEVjBUgBD8gBzCH4SdVIksYQ0DovzKoS4wLDEqMCgGA1UEAxMh
# UG93ZXJTaGVsbCBMb2NhbCBDZXJ0aWZpY2F0ZSBSb290ghABvvi0sAAYvk29NHWg
# Q1DUMAkGBSsOAwIdBQADggEBAI8+KceC8Pk+lL3s/ZY1v1ZO6jj9cKMYlMJqT0yT
# 3WEXZdb7MJ5gkDrWw1FoTg0pqz7m8l6RSWL74sFDeAUaOQEi/axV13vJ12sQm6Me
# 3QZHiiPzr/pSQ98qcDp9jR8iZorHZ5163TZue1cW8ZawZRhhtHJfD0Sy64kcmNN/
# 56TCroA75XdrSGjjg+gGevg0LoZg2jpYYhLipOFpWzAJqk/zt0K9xHRuoBUpvCze
# yrR9MljczZV0NWl3oVDu+pNQx1ALBt9h8YpikYHYrl8R5xt3rh9BuonabUZsTaw+
# xzzT9U9JMxNv05QeJHCgdCN3lobObv0IA6e/xTHkdlXTsdgxggHhMIIB3QIBATBA
# MCwxKjAoBgNVBAMTIVBvd2VyU2hlbGwgTG9jYWwgQ2VydGlmaWNhdGUgUm9vdAIQ
# mkSKRKW8Cb1IhBWj4NDm0TAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAig
# AoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUTqnRI3wKvaxsvFDJmf7/
# +YX7GBEwDQYJKoZIhvcNAQEBBQAEggEA3IKrWANAHUl2/NiwYgvoxINaU9Iebzxu
# 7hr5TN8nbxfqFFO/YeYpiF3m4c10y8oAM4q2xUnszkZxFM4tQwR3VJLURUuyAodD
# PxUL85LMb48CfOIUK3leF2pYC/Vx9ctzUYJJlnLC0ceFBWiYYbWwY5lkbdufYbQ9
# 4AgdLJ0VKgJnFPRWsLXh3ui0muQhRcgj25FF4hs3E61Es5pc6EkMvZMMqTX1OUWO
# BAjV1rlVRynMGjp+0G0luo+hCD98sKZFA1KdvCOmwD4feU9xqAKa24nVZO86TDmD
# oZ1g1sdqt1WHgX5Zc7WaTPmHJ8QtT7XV5x9UIF5Ape5AWXjs9IGBlQ==
# SIG # End signature block
