<#
  ╓──────────────────────────────────────────────────────────────────────────────────────
  ║   PowerShell PowerShell.Module.FedEx Module
  ║   Version 1.0.2 , Generated on Sun, 13 Feb 2022 17:13:28 GMT 
  ║   Description: 
  ║   Current Git Revision HEAD
  ╙──────────────────────────────────────────────────────────────────────────────────────
 #>


# ------------------------------------
# Script file - Aliases - 
# ------------------------------------
$ScriptBlockAliases = "H4sIAAAAAAAACuPl4uXiAgAPQe1DBQAAAA=="

# ------------------------------------
# Script file - Auth - 
# ------------------------------------
$ScriptBlockAuth = "H4sIAAAAAAAACuVXbW/bNhD+XqD/gVAN2MYsOwmGfWhhoI7tZMFmx6udvqAIAkaiYy6yqJJUbLfIf98dKVkSo74kQ/dlCsDI5N1zr7w7PX/23PydpHGguYjJKdP+CQvH20GqVyzWPKC4vxC3LP7y/BmB5+NwHUZMH/M45PFNa54miZBazVcijcKZFAFTqn1paRMq6bqFb/DYLQMxw32mmWxNaBxSLeSu31jSSLEOeUujlJ1IsZ7xhEU8Zv2Glikc/M6iZALg9Ib1vRMhA+blcgyo2nAdrC4b5sjut0GofWtcKCaHkoWfSd9YOUgS/Ik2glzS2lueE9qTs1E7A8gYvstfOSjYhxGHrbMRsO+huihrCp6o0MxZIJmu0AH4lOmNkLcFdKvdnVGlYDOserfxht3MqF5lihqlJiJMIwYHXGm5w9OCni9bBY/PPhHPA8d9IXolxYZ4sdCEx2RtELxXBHRLZUxe3RcI7yTXzH/L5LVQjHiRELfIkoN6Jd3GW9BAoXEnGO6KFjZyRgV7CloUBFV2tCw3x2QM8Y3+3l4o8dGzpEkDzMgrjSncrHrqviregrddmVOxWXBAskJHVDNSTwGBE3GI2g1FfMekXgh/iAetnKLtMOLeeJtwCGrB/OOmMWQ1F/RKA1KzQHfkjPhyiT6vKurXyK8yOoF17HTgOqTGnBoRHWLUMUp5rkMwSk8PbxUNY2pE+ZEmB25cjbyLBKoPe7cyQg+Jn7nqIaXjCbi4hGG6QAnMtO4QC2Yyv4SrrNWOpfhkN8myV49LmXnP4CY4ujva7G9v2RlkdD4eTMn4/dl8MfeqSVGC/zjXEoy4bFzICHzgrbRO1MtejyZc+Qqq87XYdpdQdLbdQKx7gkJj6BkB5Wv9O6MhkwouBwWQ1466HtwHDVXLX+wS5qEUmiRR1lt6W3+z2fhLIdd+KiMWByJkoVerbONYhLuvCLmRNNZXGiTY333SDEw9vQqKOu1kSEbATQU1PPs6XUuobGkuEdpiXSVOoarHmJwF6r77OCU/f5JSJX/A8qjqX/aWabOqxlcXkpd/GnEyqtKgqx2a3PsOGCg6uAG19oRO29kTVPmynCkLKKVRlXbC9ErsvWOCOzufL5xwgqBjqngAdiu8mICIo0PJOfafHXqMi2xpUmcxBBI99duBPXBu2Fl8Bynvv2PXb9inlCkNLoxeGq95tQx712dByKjgpqpExEDRJxkm7OjMvNeWNiPNa+Gep1u+3t9SswRpQEBR8z9T4iP2MKzLlzW97QGJ8ZCdAi1lztQdhHlJb1X9CG0us+GxndGR9g2+KmHRWHPBaRT1p2zjn2m2zppHMeTgJtYi6ESSBTh+Er80NhpuEDp/4pDhW+Isgk/FhMICQQivRAmx6s+nIrtzwx6+1vtWitOs7iufDVneAQrHvjcTStPoZ38v2K+Cp38uZH3PKjuEptP5yRJz90CgWs3BcbPTPB7CMsG3qVn+xGWByxyXC1jOp7DMxrD8hcTzP2D5sGjWmyLFHY+D/9aQC1R1OKjXaCjSGNKxrFBRWeYrnhQlB7/VHgwlpyn05j5p4U3G93YX169OL83vTC+BVad3d9hLTNh7d5kppU7SGKSAimjXjEomSZP8Uv6+e/hlnBWP9g8PRC+8rR+kSos1k76GwUVRc5F8HprxyNjtTIxekA1Rum6I+luJ8kCGDyoqJP9sCMznJNpVOym8wMXGjMwTFvDlDj7/GDHzLDBvVjxYmZ2EBreQFoQrogW5ZkRBEBMWdomDtgBiZaA4Cy2QMlee4AclMCJakEqJg4OVIwmNd+a9Qw4P4GWnCF1C6j6grZVmQHCMpJqswbko5AM8/mTij0bdH5siAyolh8ELyoGZMk5G70/dodEmUU7i5UnuuB/SS7Nzmd/JgjzfcehtQpbI9r9d4Oza4DtoeHRwdOQfHPmHvza/PoY+cgR9zPj5Pxw9T8f/fvL8xvR3/+wfM/eNBJgTAAA="

# ------------------------------------
# Script file - FedEx - 
# ------------------------------------
$ScriptBlockFedEx = "H4sIAAAAAAAACt1YbU/bSBD+jsR/WLmRnFyJQ6VeTwLlQwimjVqSCAeuUouQcZZkheP1rdeEFPHfb/YtXicOUOCquwtC4N2Z2ZnnmZkdZ3trG36u8iTihCYoiBhJ+V4n5/Q0HYccDxmdMJxl6A7pzxvUH/hfh4OT0faWeP6TEY6bS7lmByzdEL5ANW3MbI0IjzFqBjzkeba2ewy/4QT2h5hFOOFdOktjzDGq141owHHaz2eXmKHWUn9EeRiLnayBfkPvdncbyi1yVaXXjHmV5t266Nu399tb9yVwPmLeBGSmlJEfoVj5hMMxGL1bw+RbdzYG5w9IMibJpN4418uDnKc5Hy1SXP8WLDKOZ17AGYicG5E0ZOEM1dWD1BmKFQCCWYvicxwmQBBlC9RGNc5yvFPePwvjHB8xOhuSFMckwU+VO1gAJylmfNGHg41WoWRcVd4FXYbHwBcJY3tdRwdOAqkz2PdETs0kbF6h0uEQ/mXOMWBUK5aVIc2kBobRSOZhcYh7EGYkQne79y5qXtmg2S50aXIDwZzvAeGggD+8V5CviNsqI3zLPT+JqGAPFDtBt9fzgP6DBcdZhaL41F1wZO/unXLGCsY7zTATUO6UVsFcH/M5ZdfFYr3hDcMsg8WxDt7+NN4gPxk/z8sV3SeAojXKIKvte7WlKYEyUc8b6mOtho7w2L89ZbHhcqVagjxNKeNZMKV5PB6qQ0r1UV0ey4JoqzRfz2yz8QnHqe43bWcAQMxFD4OWASHhDKhwdtCQZkR43N4t5TvYJKIv9inv53E8YP4s5YtlhassUiVd66iQixzWnNYuAXEaAlJQXO6U8zTba7XkggepMCbci+is5VrStuB8Pq8SA8/zmLdd/ZzNCY+mqI6MG/pwu37Eia5YM9qi2OVxb2EzJa2bd60wEvBfcHqNExfdW9ozLHQrtFVohQktaOuC46IpZO5D6jnUTStaQDOOwgyIbVlaZXNC4/2KLdddE/l9XWRN5kOFzLrUHw9bGuOrUGzcIT5ldI4cktyIxEGh5MJZCssLRvzDMM9ZYixW3TyqagCSol30DuGEf6qGrsI4e1kRVRZFb1yuBRHND4EgxIdvvWBK0hQEvU4U0RyujRHOOKT0Kk5SbSNMnTT9n6I0pHPMgimOY++YjvMYexI3XfToCSAJQBVKX+jk2cCgunFtGMo+tsReuXWCJyTjbCF27TnxeHCNHKlCYAYU/zj2dncaJgmOzTD4uOSJqsA1wQ2JoZwTVdSZAPjoFeJXJvWoVK/5tzjKxaFwxXJxQwegCo9i7MUNTZpWVT60kSMcaqony56Hujn0vRnSTKv4yxRLpUfCtbl4hYhhskZrYaIm/gvVErgSUaNoewnliCRoJt1w9o3XjoP2TQd8CX469Zya3z/bG7BJmJjB43P39Ltl+btEQ1yXVRiqHC1DGFitJMARiP6Lp5VnTygjcavvmOVf3OvUhHJeO6Lwwmd7YCoL8vapzUXmpJEXqQgp9nge7psclDgMlZNwnGyR5hAZLryWCsuOOcNBTT+BTZgG7PnIfmGRLpUMN0ztFV3sDLNLCvOWIwVRGDMYmRcooskVmeTQvnXP0wY1VrLWjgQbDWucK1J6v1gs5gwZqMjjNurj+aPhyYIsR4eaSlhFhZriPRa5mcwld3WM2dyUXl5RRfP9iRR5ZZLX6ZWsiEoQmVcwoNFSHj7/PBtdabFErOrJyc3ekX/of73odLt+EIwGn/0+asKbf9GYjYlqWWPOSAm1jZ3xUA254u5KRLL8K/rjR8KR8ah6tBK7L+w2NXoNYsEanzaVjn4HuMiNN7ArztYV/Q0nN4TRRLzQwGs4GPOLhbOQkfAyxnX30D/qnH4ZXSiuTgP/pN859t0dbWvHFX/cRpk2er2x+F6LtOeVoMQebnkh2YPvIcwXTRv7zyqI0IN8xijT77S9SUIZTAWrYlZRyCOra0BlwmoFGcQ/9kZLvB8ookpxmG5WLgIh+gRrtoWNpVjFa4AZXLjmW9pfSqo++mdondKMP0Cn2bbw04dUI6c3zQv4BkJVCQHAZ/7JEwgtiT+nMRpK/htt8ZPG/Fe0RsOvaInm3Je0RUWSaIpLa480xu2trb8BUieBv/oYAAA="

# ------------------------------------
# Script file - Helpers - 
# ------------------------------------
$ScriptBlockHelpers = "H4sIAAAAAAAACs1WUWvjOBB+D+Q/iJ5hHahN920J9KHbpt2ybdJNsoQlGKrak8R3iuSVZNoQ+t93ZMup7DjZ4ziulzxY9oy++Wbm88jdThf/MaNKkcsV5RzYgxQZSJ2C6na23Q7B3x8tJvN8rrRM+TLyrJ2ckw83t9MP1nopuBIMLgUTMvKmqbZr43ZPl8A1bXe9B6XQvnO+ovKvG0k37d4DKYWs+Y4haXed5HGM2A1gAH4E+QpULNNMp4LX9v0AxsQzbnztdrwbJp4o6zt1Uug336tb1O9zePZ7purdziLnscElM5lqCKy3zX5rCLm/iuI6YaA/pzzB0vuTPMuE1GqyEjlLMJDJrxeVvhmVdO2X62Lvg3kAGqR/T3lCtZCbc0/LHE4fhEoNlfOzanOtwZZTnUqRhVmU9L8IpcnJ3PPbqhHam15ETkiwIAe83kTSI8FQDOH5LuWwH6UidAzLVVGvaNPhmo9B5Uzvlfz/14FT1/Sc6ngVeTMqOfo0mpIu/MpCAvhJvGvKFPTsK/3ftW0vEhl9Jcfh3Nd0H/AVMI9DacwuxsPj4G/jogW6vPybejukuILG9v30VhPZZKM0rEN0wQTWOJjDi1yLNTW0y4KNIRYyibzyupOauXgLIdG1FCpOvZPt2esj3358PansKbDEzEO7O7zOGdt8yylL0ZQU+LfJaWUdvMRQjNtwKiYFqJmXBVJpulfLc78e1XSlDNN7r5E0H4zHo/E/115NbrtEH/kjR8RrIWEpRc6T8gx6O4Cs0HYiuwEdfNE6m8ETDrUMzzMkzzX2dHecNwRVKWE+ynWW6+kmA39eFj46qCurmCHosBEtIp5z1xhKHvYL6HoMNAFzknocpVAZtdyUC+fl9uKSfNO3nHDE94unJOBQC4vlRbkT330W2jrcAV/qFQmWmpz1rFwaUR2qJrALgvWt1pPCoRLnbh/wWJjCmg8AW6YpvOhwYJ/jN8D36fWn+i6TS8CFJlXl+/1bNcTURnK2QmFMMhpDazoVrJtKSzp/lxrmV90dD1eHL0TYUr5dp1HrwejpT4g1CYzEhjiWiOVwOwonrndwIZe5GUN3Kb4NvoU6fePfLLkjEjdsaC5TMeCJ26QaVQk6l3yHUDsGFimnOKj2NGl65cjOjfhbOVlil0woaJCyF3tudH4Bq8c+OpsLAAA="

# ------------------------------------
# Script file - Parsing - 
# ------------------------------------
$ScriptBlockParsing = "H4sIAAAAAAAACl1T72vbMBD9Hsj/IIohNtQh/TTmEVjXtWthSQMp24cShmafa2364UnnpqHt/76T5LZ2ZYPFvXdPp3fn6WRKT93pEoXR7BtgvjEO11yBe5xOGK3bM1VJwC9CV0LfpduubY1Ft21MJ6uNNSU4l+0it+WWqzTuQ+7GBwDBpiuuK47GHpZJzaWDY/aDyw4urFEb0YIUGpYJ2o6AS5DtilT5HSyPru/B7q1AYKJmrQUHGo9ezgtnkI4gaVgbXHdSXttz1eIhHXFOreWHXfKVIw+BCGWvO1GnEczhH0u8TNZf368ILdmVvjd/ISeX1rDfmD3YbQNSDog3oFoipoTnfm8st4cLISGbX5CoJjPeyz6x8wfvaH4mxYOSLN9wbKJSpD73ffB3RKFgl0BryoaOmZ18/LDIFyf0ssWiCO/s7XrJqZShk0S93R4cgpqfGSkhNNvNgynfhcNdUWjYp1mf5kOUEsqb06l8XjZCVhZ0JNTGAi+bNGlpVJjQMWNkmL+ol/CMKBEin9iAgwLlO1IMjVglnYVQ/eqwHHOHwCiDd9gYOyb3sRHPgawRHnDMfI0OuQPvfzagfUbowfy0qrZQGl25dFhpNkjdoqX/JibS3rftcfE8Y3nN0lsXu+IipyjIWsUxJUaxWuVVxS4vC6WeZ8chPRvqtq7sHBplfv+hhu4S+pL250EX/LqqfLHjufPr5sX8YPkYo74HqK/4DewnMbjn/5Hl64R5I1JfQl9hz7SAnaX5eKFNJwTEZ/IfFjqN+3sEAAA="

# ------------------------------------
# Script file - Requests - 
# ------------------------------------
$ScriptBlockRequests = "H4sIAAAAAAAACu1YbW/bNhD+HiD/gRCC2sZqGfs2FDDaxPaaFPML7KTFMAQGLZ1twrKokVQ8d/N/75HUq1+aJg2wwrWCwJJ4fO6Fd/eQOj87T/6mcegpxkPSg1V9CL7PVEtwKQdcqn/Pzwhef7WWfgDqioU+C2fVURxFXCg5mvM48AeCeyBl7d7KRlTQZdXem7kD/QIUiGqXhj5VXKybF0rE8Jp8pEEMvwu+HLAIAhZCOnANQdRFUDqDptN/ALESTAFhUxIJkBAqJ1VnVCAOQ2TocdWLg6AvOstIraslmZESaPv9RV+wGQtp8PrHNREX4k4EdqCG/7nIxZ0E0RLgfyZN8h5U/TKK9COqYzSQpKrf2TVMJe3QTbtWQElmPQ5SGiljaHycn1vk6rsexrEgNKESUKgyVyqSbxoNTmM1d4XBdj2+rBSNitF/LTwBKhC7Qn4pmYIztR0e1cl6yxcQ1vbEDgOHGI7R3KARa8h4smTKKSi6BuqDkG2qKIq+S3I8vbQeLthno0Y7aOwqy8Ta9+RKQhCWHN8U1F1xf31A10zQUI3VOgKNU4molCsu/MquNg1f0HYo4PpKUXbEMZY9UDi0yNe0WnMHBfkykqfbQIRtYDzFlDUmIGBaQGVZLI2FHi3mbnotsG9o/zK8yv5ImTKUe+J0J1jx0bi1rUSHeUsmjfwWGAbkcobuZ4J5knW5HweQSZQnJnlT1FBIpbJsFzCLTEhT2cqgP7rdWllUdEUl89BxidmrEXVzKUTH/ug2nd6lQ590u6l/BDHhWGPOTfiAJVH/BJMh/B2DVBi04I2Jk3NwUhbwJPTFKhkCLlVoyre6C/7OTqi5LR6qUqSyiR+krZ8M6D+CwtgolW6ndT38BG9SFHQpvd1n7fnZZovV8sUdYV/x5qN4YvuPPEJy093gUWKbYpN/Qfvkiilvfn/R+Yd66v9S3qUqFknhnCjzmyjTLljCuWZZimxsA5qM6qWp7Em3pDgTzj1E8paGTfGNZVZ9b3GqTgidsq9Am9LMLHrFQi+IfRhzTIDxr781c3Occj98cTo/akI3jj7q31NoOM+An4GNt/nqGvcypB6S+pS01jQkzrDTbt/cklHncti6Js5+zrazpqRNceHMNMtMWieyk/WdYGObE5MlAVsAbqzw1nXdw2R+2gFk2w43bzOurafNzp4g2wfchFN+pFuBEx9+wxHy+bwmGibKDTrhsToR04mYXoKY3ndOvHSMJ1OLutl7MjVbnAfKAjoJ4Ai5KN1vFrZDp0Pad37XTA8RY5omzukb5w9xJPo5KMf+2G9teZjyhp331Fv+1I6afbkkFvBQO302AfzBUK65BbZLAviqH+NJwZRgDmP6Yn1eOMXhEhGn+ejlfA3jTwgCvsIjZMGmAqV8wMevzrcnyXrpepJCHZSCQv2Y7Gm/3/EyzjMpdXP2BQz145m1HAAA"



# ------------------------------------
# Loader
# ------------------------------------
function ConvertFrom-Base64CompressedScriptBlock {

    [CmdletBinding()] param(
        [String]
        $ScriptBlock
    )

    # Take my B64 string and do a Base64 to Byte array conversion of compressed data
    $ScriptBlockCompressed = [System.Convert]::FromBase64String($ScriptBlock)

    # Then decompress script's data
    $InputStream = New-Object System.IO.MemoryStream(, $ScriptBlockCompressed)
    $GzipStream = New-Object System.IO.Compression.GzipStream $InputStream, ([System.IO.Compression.CompressionMode]::Decompress)
    $StreamReader = New-Object System.IO.StreamReader($GzipStream)
    $ScriptBlockDecompressed = $StreamReader.ReadToEnd()
    # And close the streams
    $GzipStream.Close()
    $InputStream.Close()

    $ScriptBlockDecompressed
}

# For each scripts in the module, decompress and load it.
# Set a flag in the Script Scope so that the scripts know we are loading a module
# so he can have a specific logic
$Script:LoadingState = $True
$ScriptList = @('Aliases','Auth','FedEx','Helpers','Parsing','Requests')
$ScriptList | ForEach-Object {
    $ScriptId = $_
     $ScriptBlock = "`$ScriptBlock$($ScriptId)" | Invoke-Expression
    $ClearScript = ConvertFrom-Base64CompressedScriptBlock -ScriptBlock $ScriptBlock
    try{
        $ClearScript | Invoke-Expression
    }catch{
        Write-Host "===============================" -f DarkGray
        Write-Host "$ClearScript" -f DarkGray
        Write-Host "===============================" -f DarkGray
        Write-Error "ERROR IN script $ScriptId . Details $_"
    }
}
$Script:LoadingState = $False



